﻿using System;

namespace TestLib
{
    public class Interval
    {
        public double x1, x2;

        public void Init(double a, double b)
        {
            x1 = a;
            x2 = b;
        }

        public void Read()
        {
            Console.Write("Введите начальное значение интервала: ");
            x1 = Convert.ToDouble(Console.ReadLine());
            Console.Write("Введите конечное значение интервала: ");
            x2 = Convert.ToDouble(Console.ReadLine());
        }

        public void Display()
        {
            Console.WriteLine("[" + x1 + ", " + x2 + "]");
        }

        public double Length()
        {
            return x2 - x1;
        }

        public static Interval Add(Interval interval1, Interval interval2)
        {
            Interval result = new Interval();
            result.x1 = interval1.x1;
            result.x2 = interval2.x2;
            return result;
        }

        static void Main()
        {
            // Создаем два объекта класса Interval
            Interval interval1 = new Interval();
            Interval interval2 = new Interval();

            // Ввод интервалов с клавиатуры
            Console.WriteLine("Введите параметры первого интервала:");
            interval1.Read();

            Console.WriteLine("Введите параметры второго интервала:");
            interval2.Read();

            // Вывод интервалов
            Console.Write("Первый интервал: ");
            interval1.Display();
            Console.Write("Второй интервал: ");
            interval2.Display();

            // Вызываем метод Add для сложения интервалов
            Interval resultInterval = Interval.Add(interval1, interval2);

            // Выводим результат сложения
            Console.Write("Результат сложения интервалов: ");
            resultInterval.Display();

            // Создаем динамический объект класса Interval
            Interval dynamicInterval = new Interval();

            // Ввод данных для динамического интервала
            Console.WriteLine("Введите параметры динамического интервала:");
            dynamicInterval.Read();

            // Вывод динамического интервала
            Console.Write("Динамический интервал: ");
            dynamicInterval.Display();

            // Создаем статический массив объектов Interval
            const int staticArraySize = 2;
            Interval[] staticIntervalArray = new Interval[staticArraySize];

            // Инициализируем элементы статического массива
            for (int i = 0; i < staticArraySize; ++i)
            {
                Console.WriteLine("Интервал " + (i + 1) + ":");
                staticIntervalArray[i] = new Interval();
                staticIntervalArray[i].Read();
            }

            // Вывод интервалов в статическом массиве
            for (int i = 0; i < staticArraySize; ++i)
            {
                Console.Write("Интервал " + (i + 1) + ": ");
                staticIntervalArray[i].Display();
            }

            // Создаем динамический массив объектов Interval
            const int dynamicArraySize = 2;
            Interval[] dynamicIntervalArray = new Interval[dynamicArraySize];

            // Инициализируем элементы динамического массива
            for (int i = 0; i < dynamicArraySize; ++i)
            {
                Console.WriteLine("Интервал " + (i + 1) + ":");
                dynamicIntervalArray[i] = new Interval();
                dynamicIntervalArray[i].Read();
            }

            // Вывод интервалов в динамическом массиве
            for (int i = 0; i < dynamicArraySize; ++i)
            {
                Console.Write("Интервал " + (i + 1) + ": ");
                dynamicIntervalArray[i].Display();
            }

            // Сложение интервалов в статическом массиве
            Interval sumStaticInterval = new Interval();
            sumStaticInterval.Init(0, 0);
            for (int i = 0; i < staticArraySize; ++i)
            {
                sumStaticInterval = Interval.Add(sumStaticInterval, staticIntervalArray[i]);
            }

            // Сложение интервалов в динамическом массиве
            Interval sumDynamicInterval = new Interval();
            sumDynamicInterval.Init(0, 0);
            for (int i = 0; i < dynamicArraySize; ++i)
            {
                sumDynamicInterval = Interval.Add(sumDynamicInterval, dynamicIntervalArray[i]);
            }

            // Вывод суммы интервалов в статическом массиве
            Console.Write("Результат сложения интервалов в статическом массиве: ");
            sumStaticInterval.Display();

            // Вывод суммы интервалов в динамическом массиве
            Console.Write("Результат сложения интервалов в динамическом массиве: ");
            sumDynamicInterval.Display();
        }
    }
}
