﻿using System;

// Интерфейс посетителя
public interface IVisitor
{
    void Visit(Movie movie);
}

// Интерфейс для кинофильма
public interface IMovie
{
    void Accept(IVisitor visitor);
}

// Класс кинофильма
public class Movie : IMovie
{
    public decimal Expenses { get; set; }
    public decimal Revenue { get; set; }

    public Movie(decimal expenses, decimal revenue)
    {
        Expenses = expenses;
        Revenue = revenue;
    }

    // Метод для вычисления окупаемости фильма
    public decimal CalculateROI()
    {
        return (Revenue / Expenses) * 100;
    }

    // Принимает посетителя для изменения полей
    public void Accept(IVisitor visitor)
    {
        visitor.Visit(this);
    }
}

// Реализация посетителя для изменения значений полей
public class FieldValueVisitor : IVisitor
{
    private decimal newExpenses;
    private decimal newRevenue;

    public FieldValueVisitor(decimal newExpenses, decimal newRevenue)
    {
        this.newExpenses = newExpenses;
        this.newRevenue = newRevenue;
    }

    // Изменение значений полей кинофильма
    public void Visit(Movie movie)
    {
        movie.Expenses = newExpenses;
        movie.Revenue = newRevenue;
    }
}

class Program
{
    static void Main()
    {
        IMovie movie = new Movie(1000000, 2000000);

        Console.WriteLine("Исходные значения:");
        Console.WriteLine($"Затраты: {((Movie)movie).Expenses}");
        Console.WriteLine($"Доход: {((Movie)movie).Revenue}");

        // Создаем посетителя
        IVisitor visitor = new FieldValueVisitor(1500000, 2500000);

        // Применяем посетителя к кинофильму
        movie.Accept(visitor);

        Console.WriteLine("\nНовые значения после посещения посетителя:");
        Console.WriteLine($"Затраты: {((Movie)movie).Expenses}");
        Console.WriteLine($"Доход: {((Movie)movie).Revenue}");
    }
}