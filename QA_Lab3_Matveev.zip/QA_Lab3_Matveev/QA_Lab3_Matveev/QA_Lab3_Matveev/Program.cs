﻿using System;

class Interval
{
    protected double x1, x2;

    // Конструктор с параметрами для базового класса
    public Interval(double a, double b)
    {
        x1 = a;
        x2 = b;
    }

    public void Read()
    {
        Console.Write("Введите начальное значение интервала: ");
        x1 = Convert.ToDouble(Console.ReadLine());
        Console.Write("Введите конечное значение интервала: ");
        x2 = Convert.ToDouble(Console.ReadLine());
    }

    public void Display()
    {
        Console.WriteLine("[" + x1 + ", " + x2 + "]");
    }

    public double Length()
    {
        return x2 - x1;
    }

    public static Interval Add(Interval interval1, Interval interval2)
    {
        Interval result = new Interval(interval1.x1, interval2.x2);
        return result;
    }
}

class IntervalOnPlane : Interval
{
    private double z;

    // Конструктор с параметрами для производного класса
    public IntervalOnPlane(double a, double b, double c) : base(a, b)
    {
        z = c;
    }

    public void PutZ(double value)
    {
        z = value;
    }

    public double GetZ()
    {
        return z;
    }

    public new double Length()
    {
        // Длина интервала плюс расстояние z
        return base.Length() + z;
    }
}

class Program
{
    static void Main()
    {
        // Ваш предоставленный код
        Interval interval1 = new Interval(0, 0); // Заменено на создание объекта с использованием конструктора
        Interval interval2 = new Interval(0, 0); // Заменено на создание объекта с использованием конструктора

        Console.WriteLine("Введите параметры первого интервала:");
        interval1.Read();

        Console.WriteLine("Введите параметры второго интервала:");
        interval2.Read();

        Console.Write("Первый интервал: ");
        interval1.Display();
        Console.Write("Второй интервал: ");
        interval2.Display();

        Interval resultInterval = Interval.Add(interval1, interval2);

        Console.Write("Результат сложения интервалов: ");
        resultInterval.Display();

        // Вставляем предыдущий код
        // Создание статических объектов
        Interval staticBaseInterval = new Interval(1, 10);
        IntervalOnPlane staticDerivedInterval = new IntervalOnPlane(1, 10, 5);

        // Демонстрация работы с public методами статического базового класса
        Console.WriteLine("\nСтатический базовый интервал:");
        staticBaseInterval.Display();
        Console.WriteLine("Длина статического базового интервала: " + staticBaseInterval.Length());

        // Демонстрация работы с public методами статического производного класса
        Console.WriteLine("\nСтатический производный интервал:");
        staticDerivedInterval.Display();
        Console.WriteLine("Длина статического производного интервала: " + staticDerivedInterval.Length());
        Console.WriteLine("z для статического производного интервала: " + staticDerivedInterval.GetZ());

        // Создание динамических объектов
        Interval dynamicBaseInterval = new Interval(5, 15);
        IntervalOnPlane dynamicDerivedInterval = new IntervalOnPlane(5, 15, 8);

        // Демонстрация работы с public методами динамического базового класса
        Console.WriteLine("\nДинамический базовый интервал:");
        dynamicBaseInterval.Display();
        Console.WriteLine("Длина динамического базового интервала: " + dynamicBaseInterval.Length());

        // Демонстрация работы с public методами динамического производного класса
        Console.WriteLine("\nДинамический производный интервал:");
        dynamicDerivedInterval.Display();
        Console.WriteLine("Длина динамического производного интервала: " + dynamicDerivedInterval.Length());
        Console.WriteLine("z для динамического производного интервала: " + dynamicDerivedInterval.GetZ());
    }
}